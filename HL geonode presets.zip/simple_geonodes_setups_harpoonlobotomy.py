bl_info = {
    "name": "Geometry Nodes Presets",
    "author": "HarpoonLobotomy",
    "version": (0, 0, 1),
    "blender": (4, 3, 2),  # Make sure this is appropriate for your version
    "description": "This addon allows users to select and apply Geometry Nodes from external .blend files.",
    "category": "Object",
}

import bpy
import os
import zipfile

# Get the directory where the current script is located
def get_default_blend_file_path():
    script_path = os.path.abspath(__file__)
    if zipfile.is_zipfile(script_path):
        # If the script is inside a zip file, extract it
        with zipfile.ZipFile(script_path, 'r') as zip_ref:
            # You can change this to a specific .blend file within the zip
            blend_file = "simple_geonodes_setups_harpoonlobotomy.blend"  # Default .blend filename within the zip
            return os.path.join(os.path.dirname(script_path), blend_file)
    else:
        # If the script is not in a zip, set a default path relative to the script's location
        return os.path.join(os.path.dirname(script_path), "simple_geonodes_setups_harpoonlobotomy.blend")


# Addon Preferences Class to store the file path in Preferences
class AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    blend_file_path: bpy.props.StringProperty(
        name="Blend File Path",
        description="Path to the .blend file containing the Geometry Nodes",
        subtype='FILE_PATH',
        default=get_default_blend_file_path(),  # Set default path based on the script's location
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "blend_file_path")
        
        # Add button to reset to default .blend file
        layout.operator("preferences.reset_to_default_blend_file", text="Reset to Default .blend")


# Operator to reset the .blend file path to the default
class ResetToDefaultBlendOperator(bpy.types.Operator):
    bl_idname = "preferences.reset_to_default_blend_file"
    bl_label = "Reset to Default .blend File"

    def execute(self, context):
        preferences = bpy.context.preferences.addons[__name__].preferences
        # Set the blend file path back to the default one from the .zip
        preferences.blend_file_path = get_default_blend_file_path()
        self.report({'INFO'}, "Blend file path reset to default.")
        return {'FINISHED'}


# Function to update the node groups when the user inputs the file path
def update_blend_file_path(self, context):
    # Clear previous node group names
    context.scene.node_group_names.clear()

    # Get the blend file path from the preferences
    preferences = bpy.context.preferences.addons[__name__].preferences
    blend_file_path = preferences.blend_file_path

    if blend_file_path == "" or not os.path.exists(blend_file_path):
        self.report({'ERROR'}, f"Invalid or missing .blend file path: {blend_file_path}")
        return
    else:
        with bpy.data.libraries.load(blend_file_path, link=False) as (data_from, data_to):
            node_group_names = data_from.node_groups
            if node_group_names:
                # Dynamically add node group names to the collection
                for name in node_group_names:
                    item = context.scene.node_group_names.add()
                    item.name = name

                # Update the UI to show the node groups in a list
                bpy.context.area.tag_redraw()
            else:
                self.report({'ERROR'}, f"No node groups found in the .blend file: {blend_file_path}")


# Create an operator to handle the node group selection and apply the modifier
class ApplyGeoNodesModifierOperator(bpy.types.Operator):
    bl_idname = "object.apply_geonodes_modifier"
    bl_label = "Apply Geometry Nodes Modifier"

    node_group_name: bpy.props.StringProperty()

    def execute(self, context):
        scene = context.scene
        node_group_name = self.node_group_name

        # Access the addon preferences to get the blend file path
        preferences = bpy.context.preferences.addons[__name__].preferences
        blend_file_path = preferences.blend_file_path

        if not os.path.exists(blend_file_path):
            self.report({'ERROR'}, f"The .blend file does not exist at: {blend_file_path}")
            return {'CANCELLED'}

        with bpy.data.libraries.load(blend_file_path, link=False) as (data_from, data_to):
            node_group_names = data_from.node_groups
            if node_group_name not in node_group_names:
                self.report({'ERROR'}, f"Node group '{node_group_name}' not found in the .blend file.")
                return {'CANCELLED'}

            bpy.ops.wm.append(
                filepath=os.path.join(blend_file_path, "NodeTree", node_group_name),
                directory=os.path.join(blend_file_path, "NodeTree"),
                filename=node_group_name
            )

            if node_group_name in bpy.data.node_groups:
                obj = bpy.context.object
                geo_modifier = obj.modifiers.new(name="GeometryNodes", type='NODES')
                geo_modifier.node_group = bpy.data.node_groups[node_group_name]
                self.report({'INFO'}, f"Geometry Nodes tree '{node_group_name}' added as modifier.")
            else:
                self.report({'ERROR'}, f"Node group '{node_group_name}' not found in bpy.data.node_groups.")
        
        return {'FINISHED'}


# Create a custom property to store the selected node group name
def update_enum_items(context):
    # Dynamically populate the list of node groups for the panel
    scene = context.scene
    items = [(group.name, group.name, "") for group in scene.node_group_names]

    return items


class NodeGroupSelectionPanel(bpy.types.Panel):
    bl_label = "Harpoon's Geonodes"
    bl_idname = "OBJECT_PT_node_group_selection"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "HL Geonodes"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # Refresh button to load node groups
        layout.operator("object.refresh_node_groups", text="Refresh Node Groups")

        # Add a gap between the 'reset' button and the node group list
        layout.separator()

        # Check if a valid blend file is set in preferences
        preferences = bpy.context.preferences.addons[__name__].preferences
        blend_file_path = preferences.blend_file_path

        if blend_file_path == "" or not os.path.exists(blend_file_path):
            # Display instructions in multiple lines using multiple label calls
            layout.label(text="No node groups found.")
            layout.label(text="Choose .blend in prefs")
            layout.label(text="then click 'refresh'")
        else:
            # Display the node group names in a list for selection
            node_groups = update_enum_items(context)
            if node_groups:
                for group_name, _, _ in node_groups:
                    row = layout.row()
                    # When clicked, apply the node group directly
                    row.operator("object.apply_geonodes_modifier", text=group_name).node_group_name = group_name
            else:
                layout.label(text="No node groups found.")

        # No need for the Apply button anymore as applying happens directly when clicking a node group


class RefreshNodeGroupsOperator(bpy.types.Operator):
    bl_idname = "object.refresh_node_groups"
    bl_label = "Refresh Node Groups"

    def execute(self, context):
        update_blend_file_path(self, context)  # Trigger the function to update node groups
        return {'FINISHED'}


def register():
    bpy.utils.register_class(NodeGroupSelectionPanel)
    bpy.utils.register_class(ApplyGeoNodesModifierOperator)
    bpy.utils.register_class(RefreshNodeGroupsOperator)
    bpy.utils.register_class(AddonPreferences)
    bpy.utils.register_class(ResetToDefaultBlendOperator)

    # Register custom properties on the Scene
    bpy.types.Scene.node_group_names = bpy.props.CollectionProperty(type=bpy.types.PropertyGroup)
    bpy.types.Scene.selected_node_group = bpy.props.StringProperty(
        name="Selected Node Group",
        description="Name of the selected node group"
    )


def unregister():
    bpy.utils.unregister_class(NodeGroupSelectionPanel)
    bpy.utils.unregister_class(ApplyGeoNodesModifierOperator)
    bpy.utils.unregister_class(RefreshNodeGroupsOperator)
    bpy.utils.unregister_class(AddonPreferences)
    bpy.utils.unregister_class(ResetToDefaultBlendOperator)

    # Remove custom properties from the Scene
    del bpy.types.Scene.node_group_names
    del bpy.types.Scene.selected_node_group


if __name__ == "__main__":
    register()
